import express from 'express';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import OpenAI from 'openai';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = process.env.PORT || 10000;
const MODEL = process.env.OPENAI_MODEL || 'gpt-6.2-astra';

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: '18mb' }));
app.use('/api/', rateLimit({ windowMs: 60_000, limit: 20, standardHeaders: 'draft-7', legacyHeaders: false }));
app.use(express.static(path.join(__dirname, 'public')));

app.get('/api/health', (_req, res) => res.json({ ok: true, configured: Boolean(process.env.OPENAI_API_KEY) }));

app.post('/api/chat', async (req, res) => {
  if (!process.env.OPENAI_API_KEY) {
    return res.status(503).json({ error: 'Сервер ещё не подключён к OpenAI. Добавьте OPENAI_API_KEY в настройках сервера.' });
  }
  const { messages, attachment } = req.body ?? {};
  if (!Array.isArray(messages) || messages.length === 0) {
    return res.status(400).json({ error: 'Напишите сообщение.' });
  }
  if (messages.length > 30) return res.status(400).json({ error: 'Слишком длинная история чата. Начните новый чат.' });

  try {
    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const input = messages.slice(-20).map((m, index, arr) => {
      const role = m.role === 'assistant' ? 'assistant' : 'user';
      const text = String(m.content ?? '').slice(0, 12000);
      const content = role === 'assistant' ? text : [{ type: 'input_text', text }];
      if (index === arr.length - 1 && role === 'user' && attachment?.data && attachment?.mimeType) {
        const dataUrl = `data:${attachment.mimeType};base64,${attachment.data}`;
        if (attachment.mimeType.startsWith('image/')) content.push({ type: 'input_image', image_url: dataUrl });
        else if (attachment.mimeType === 'application/pdf') content.push({ type: 'input_file', filename: attachment.name || 'document.pdf', file_data: dataUrl });
      }
      return { role, content };
    });
    const response = await client.responses.create({
      model: MODEL,
      instructions: 'Ты — Аля, дружелюбный, умный и внимательный ИИ-помощник. Отвечай на языке пользователя, по умолчанию на русском. Будь ясной, полезной и честной. Если не знаешь — скажи. Не утверждай, что помнишь прошлые чаты вне переданной истории.',
      input
    });
    res.json({ reply: response.output_text || 'Не удалось получить текстовый ответ. Попробуйте ещё раз.' });
  } catch (error) {
    console.error('OpenAI request failed:', error?.status || '', error?.message || error);
    const status = error?.status === 401 ? 502 : 500;
    res.status(status).json({ error: error?.status === 401 ? 'Серверный API-ключ не принят. Проверьте его в настройках сервера.' : 'Не получилось получить ответ от ИИ. Попробуйте ещё раз позже.' });
  }
});

app.get('*', (_req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));
app.listen(PORT, '0.0.0.0', () => console.log(`Alya AI listening on ${PORT}`));
